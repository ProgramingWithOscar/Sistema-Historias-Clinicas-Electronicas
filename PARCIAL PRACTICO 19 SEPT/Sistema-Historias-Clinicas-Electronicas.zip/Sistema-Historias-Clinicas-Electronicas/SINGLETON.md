# Patrón Singleton en el código

## ¿Dónde se usa?

El patrón está implementado en la clase **`AuditLogger`**, que corresponde al caso
de uso 2 descrito en el README (*gestor de auditoría / logging clínico*).

| | Archivo |
|---|---|
| **La clase Singleton** | `backend/app/Support/Audit/AuditLogger.php` |
| **Quién la usa** | `backend/app/Http/Controllers/Api/AuthController.php` (login, logout y consulta de sesión) |
| Enlace con el contenedor de Laravel | `backend/app/Providers/AppServiceProvider.php` |
| Pruebas que verifican el patrón | `backend/tests/Unit/AuditLoggerSingletonTest.php` |

### Diagrama UML

```mermaid
classDiagram
    direction TB

    class AuditLogger {
        -instance AuditLogger
        -requestId string
        -sequence int
        -__construct() void
        +getInstance() AuditLogger
        -__clone() void
        +__wakeup() void
        +resetInstance() void
        +requestId() string
        +eventCount() int
        +record(action, outcome, actorId, subjectType, subjectId, metadata, request) AuditLog
    }

    class AuditOutcome {
        <<enumeration>>
        Success
        Failure
        Denied
        +label() string
    }

    class AuditLog {
        <<Eloquent>>
        +request_id string
        +sequence int
        +action string
        +outcome AuditOutcome
        +metadata array
        +actor() BelongsTo
    }

    class AuthController {
        <<cliente>>
    }
    class DeviceReadingFactory {
        <<cliente>>
    }
    class ClinicalRecordExporter {
        <<cliente>>
    }
    class ClinicalEncounterController {
        <<cliente>>
    }

    AuditLogger --> AuditLog : persiste eventos
    AuditLog --> AuditOutcome : clasifica

    AuthController ..> AuditLogger : getInstance()
    DeviceReadingFactory ..> AuditLogger : getInstance()
    ClinicalRecordExporter ..> AuditLogger : getInstance()
    ClinicalEncounterController ..> AuditLogger : getInstance()
```

`instance`, `getInstance()` y `resetInstance()` son **estáticos**. Las tres
puertas de entrada están cerradas a propósito: `__construct()` y `__clone()` son
privados y `__wakeup()` lanza excepción, de modo que no hay forma de obtener una
segunda instancia ni por `new`, ni por `clone`, ni deserializando.

Nótese que ningún cliente recibe el logger por inyección: todos lo piden con
`getInstance()`, que es justo lo que garantiza que `requestId` y `sequence` sean
los mismos para toda la petición.

## El núcleo del patrón

Extracto de `backend/app/Support/Audit/AuditLogger.php`:

```php
final class AuditLogger
{
    /** Única instancia viva del logger en el proceso. */
    private static ?self $instance = null;

    /** Correlativo compartido por todos los eventos de una misma petición. */
    private readonly string $requestId;

    /** Orden monotónico de los eventos; sólo tiene sentido si la instancia es única. */
    private int $sequence = 0;

    /** Privado: nadie fuera de la clase puede hacer `new AuditLogger()`. */
    private function __construct()
    {
        $this->requestId = (string) Str::uuid();
    }

    /** Único punto de acceso a la instancia. */
    public static function getInstance(): self
    {
        return self::$instance ??= new self;
    }

    /** Bloquea la clonación: `clone $logger` crearía una segunda instancia. */
    private function __clone(): void {}

    /** Bloquea la deserialización, la otra vía para duplicar la instancia. */
    public function __wakeup(): void
    {
        throw new \LogicException('AuditLogger es un Singleton y no puede deserializarse.');
    }
}
```

Y así lo consume `AuthController`, sin instanciarlo ni recibirlo por inyección:

```php
$audit = AuditLogger::getInstance();

$audit->record(
    action: 'auth.login.succeeded',
    actorId: $user->id,
    subjectType: User::class,
    subjectId: $user->id,
    request: $request,
);
```

## ¿Para qué se usa?

Para que *todos* los accesos y cambios sobre una historia clínica se registren a
través de un único componente. Hoy audita el flujo de autenticación
(`auth.login.succeeded`, `auth.login.failed`, `auth.logout`, `auth.session.read`)
y guarda cada evento en la tabla `audit_logs`.

## ¿Por qué tiene que ser Singleton?

Porque el logger mantiene dos datos que sólo son correctos si existe una sola
instancia en toda la petición:

- `requestId`: identificador que agrupa todos los eventos de una misma atención.
- `sequence`: contador que da el orden cronológico de esos eventos.

Si hubiera dos instancias, los eventos de un mismo login quedarían repartidos en
dos identificadores distintos y **ambos empezarían a contar desde 1**, con lo que
se perdería el orden exigido por la trazabilidad de la HCEI (Ley 2015 de 2020 y
Res. 1995 de 1999). Además, centralizarlo evita que un módulo pueda "saltarse" la
auditoría creando su propio logger.

## ¿Cómo se garantiza la instancia única?

Constructor `private` (nadie puede hacer `new AuditLogger()`), acceso sólo por
`AuditLogger::getInstance()`, `__clone()` privado y `__wakeup()` que lanza
excepción para cerrar la vía de la deserialización.

